/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitytuitioncalculator;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;

/**
 *
 * @author 7medeh
 */
public class UniversityTuitionCalculator extends Frame implements ActionListener {

    University university;

    private TextField UniversityNameField, MinGPARequiredField, OutOfStateTuitionField, InStateTuitionField,
            AcceptanceRateField, GraduationRateField, StudentsEnrolledField,
            ApplicationFeeField, ApplicationDeadlineField;

    private Button next, done;   

    private DataInputStream input;

    public UniversityTuitionCalculator() {
        super("Universities");

// Attempt to open the file
        try {
            input = new DataInputStream(new FileInputStream("universities.dat"));
        } catch (IOException e) {
            System.err.println("File not opened properly\n" + e.toString());
            System.exit(1);
        }

        setSize(600, 450);
        setLayout(new GridLayout(11, 2));
        setBackground(Color.PINK);

// Get the size of the screen and center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (((screenSize.width - this.getWidth()) / 1) / 2);
        int y = (((screenSize.height - this.getHeight()) / 2) / 2);
        this.setLocation(x, y);

// create the components of the Frame
        add(new Label(" University Name"));
        UniversityNameField = new TextField(20);
        UniversityNameField.setEditable(false);
        add(UniversityNameField);

        add(new Label(" Minimum GPA"));
        MinGPARequiredField = new TextField(20);
        MinGPARequiredField.setEditable(false);
        add(MinGPARequiredField);

        add(new Label(" Out-of-State Tuition"));
        OutOfStateTuitionField = new TextField(20);
        OutOfStateTuitionField.setEditable(false);
        add(OutOfStateTuitionField);

        add(new Label(" In-State Tuition"));
        InStateTuitionField = new TextField(20);
        InStateTuitionField.setEditable(false);
        add(InStateTuitionField);

        add(new Label(" Acceptance Rate"));
        AcceptanceRateField = new TextField(20);
        AcceptanceRateField.setEditable(false);
        add(AcceptanceRateField);

        add(new Label(" Gradutation Rate"));
        GraduationRateField = new TextField(20);
        GraduationRateField.setEditable(false);
        add(GraduationRateField);

        add(new Label(" Students Enrolled"));
        StudentsEnrolledField = new TextField(20);
        StudentsEnrolledField.setEditable(false);
        add(StudentsEnrolledField);

        add(new Label(" Application Fee"));
        ApplicationFeeField = new TextField(20);
        ApplicationFeeField.setEditable(false);
        add(ApplicationFeeField);

        add(new Label(" Application Deadline"));
        ApplicationDeadlineField = new TextField(20);
        ApplicationDeadlineField.setEditable(false);
        add(ApplicationDeadlineField);

        next = new Button("Next");
        next.addActionListener(this);
        add(next);

        done = new Button("Done");
        done.addActionListener(this);
        add(done);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == next) {
            readRecord();
        } else {
            closeFile();
        }
    }

    public void readRecord() {
        String universityName;
        double minGpaRequired;
        int outOfStateTuition;
        int inStateTuition;
        double acceptanceRate;
        double graduationRate;
        int studentsEnrolled;
        int applicationFee;
        String applicationDeadlineSTRING;

// input the values from the file
        try {
            universityName = input.readUTF();
            minGpaRequired = input.readDouble();
            outOfStateTuition = input.readInt();
            inStateTuition = input.readInt();
            acceptanceRate = input.readDouble();
            graduationRate = input.readDouble();
            studentsEnrolled = input.readInt();
            applicationFee = input.readInt();
            applicationDeadlineSTRING = input.readUTF();
            String[] deadline = applicationDeadlineSTRING.split("-");
            Date applicationDeadline = new Date(Integer.parseInt(deadline[0]),Integer.parseInt(deadline[1]), Integer.parseInt(deadline[2]));

            university = new University(universityName, minGpaRequired,
                    outOfStateTuition, inStateTuition, acceptanceRate,
                    graduationRate, studentsEnrolled, applicationFee, applicationDeadline);

            System.out.println(university); //toString()

            UniversityNameField.setText(String.valueOf(universityName));
            MinGPARequiredField.setText("" + minGpaRequired);
            OutOfStateTuitionField.setText("" + outOfStateTuition);
            InStateTuitionField.setText("" + inStateTuition);

            AcceptanceRateField.setText("" + acceptanceRate);
            GraduationRateField.setText("" + graduationRate);
            StudentsEnrolledField.setText("" + studentsEnrolled);

            ApplicationFeeField.setText("" + applicationFee);
            ApplicationDeadlineField.setText(applicationDeadline.toString());

        } catch (EOFException eof) {
            closeFile();
        } catch (IOException e) {
            System.err.println("Error during read from file\n"
                    + e.toString());
            System.exit(1);
        }
    }

    private void closeFile() {
        try {
            input.close();
            System.exit(0);
        } catch (IOException e) {
            System.err.println("Error closing file\n"
                    + e.toString());
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        new UniversityTuitionCalculator();
        // TODO code application logic here
    }

}
