/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitytuitioncalculator;

/**
 *
 * @author 7medeh
 */
public class University {
    String universityName;
    double minGpaRequired;
    
    int outOfStateTuition;
    int inStateTuition;
    
    double acceptanceRate;
    double graduationRate;

    int studentsEnrolled;
    double applicationFee;
    Date applicationDeadline;

    public University(String universityName, double minGpaRequired, 
            int outOfStateTuition, int inStateTuition, double acceptanceRate,
            double graduationRate, int studentsEnrolled, double applicationFee,
            Date applicationDeadline){
        this.universityName = universityName;
        this.minGpaRequired = minGpaRequired;
        this.outOfStateTuition = outOfStateTuition;
        this.inStateTuition = inStateTuition;
        this.acceptanceRate = acceptanceRate;
        this.graduationRate = graduationRate;
        this.studentsEnrolled = studentsEnrolled;
        this.applicationFee = applicationFee;
        this.applicationDeadline = applicationDeadline;
       
    } 
    
    public String toString(){
        return this.universityName + ": Must have a " + this.minGpaRequired +
                " to be considered for admission. Out-of-State tuition is $" + 
                this.outOfStateTuition + " and in-State tuition is $" + this.inStateTuition + 
                " if the student is a resident. The acceptance rate is " + this.acceptanceRate + 
                "% and the graduation rate is " + this.graduationRate + "%." + 
                this.universityName + " has " + this.studentsEnrolled + " students enrolled "
                + "at the time. The application fee is $" + this.applicationFee + " and "
                + "the deadline for applications is " + this.applicationDeadline.toString();
    }
    
    
    
}
