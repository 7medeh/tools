/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitytuitioncalculator;

/**
 *
 * @author 7medeh
 */
public class Date {

    int day;
    int month;
    int year;

    Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }
    
    public String toString(){
        return this.month + "/" + this.day + "/" + this.year;
    }

}
