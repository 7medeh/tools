/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitytuitioncalculator;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author 7medeh
 */
public class WriteUniversityInfo extends Frame implements ActionListener {

    private final TextField UniversityNameField, MinGPARequiredField, OutOfStateTuitionField, InStateTuitionField,
            AcceptanceRateField, GraduationRateField, StudentsEnrolledField,
            ApplicationFeeField, ApplicationDeadlineField;
    private final Button enter,
            done;

    private DataOutputStream output;

    public WriteUniversityInfo() {
        super("Store University Information");

        // Open the file
        try {
            output = new DataOutputStream(new FileOutputStream("universities.dat"));
        } catch (IOException e) {
            System.err.println(e.toString()+ "File not opened properly\n");
            System.exit(1);
        }

        setSize(600, 450);
        setLayout(new GridLayout(11,2));

        // Get the size of the screen
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (((screenSize.width - this.getWidth()) / 1) / 2);
        int y = (((screenSize.height - this.getHeight()) / 2) / 2);
        this.setLocation(x, y);

        // create the components of the Frame
        add(new Label(" University Name:"));
        UniversityNameField = new TextField();
        add(UniversityNameField);

        add(new Label(" Minimum GPA Required:"));
        MinGPARequiredField = new TextField();
        add(MinGPARequiredField);

        add(new Label(" Out-Of-State Tuition Costs:"));
        OutOfStateTuitionField = new TextField();
        add(OutOfStateTuitionField);

        add(new Label(" In-State Tuition Costs:"));
        InStateTuitionField = new TextField();
        add(InStateTuitionField);

        add(new Label(" Acceptance Rate:"));
        AcceptanceRateField = new TextField();
        add(AcceptanceRateField);

        add(new Label(" Graduation Rate:"));
        GraduationRateField = new TextField();
        add(GraduationRateField);

        add(new Label(" Amount of Students Enrolled:"));
        StudentsEnrolledField = new TextField();
        add(StudentsEnrolledField);

        add(new Label(" Application Fee Cost:"));
        ApplicationFeeField = new TextField();
        add(ApplicationFeeField);

        add(new Label(" Application Deadline:"));
        ApplicationDeadlineField = new TextField();
        add(ApplicationDeadlineField);

        enter = new Button("Enter");
        enter.addActionListener(this);
        add(enter);

        done = new Button("Done");
        done.addActionListener(this);
        add(done);

        setVisible(true);
        UniversityNameField.requestFocus();

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enter) {
            addRecord();
        }

        if (e.getSource() == done) {
            try {
                output.close();
            } catch (IOException io) {
                System.err.println("File not closed properly\n"
                        + io.toString());
                System.exit(1);
            }

            System.exit(0);
        }
    }

    public void addRecord() {
        String universityNameTemp = "";
        double minimumGpaRequired;
        int outOfStateTuition;
        int inStateTuition;
        double acceptanceRate;
        double graduationRate;
        int studentsEnrolled;
        int applicationFee;
        String applicationDeadline;

        if (!UniversityNameField.getText().equals("")) {

            // output the values to the file
            try {
                universityNameTemp = UniversityNameField.getText();

                if (universityNameTemp.length() > 0) {
                    output.writeUTF(universityNameTemp);

                    minimumGpaRequired = Double.parseDouble(MinGPARequiredField.getText());
                    output.writeDouble(minimumGpaRequired);

                    outOfStateTuition = Integer.parseInt(OutOfStateTuitionField.getText());
                    output.writeInt(outOfStateTuition);

                    inStateTuition = Integer.parseInt(InStateTuitionField.getText());
                    output.writeInt(inStateTuition);

                    acceptanceRate = Double.parseDouble(AcceptanceRateField.getText());
                    output.writeDouble(acceptanceRate);

                    graduationRate = Double.parseDouble(GraduationRateField.getText());
                    output.writeDouble(graduationRate);

                    studentsEnrolled = Integer.parseInt(StudentsEnrolledField.getText());
                    output.writeInt(studentsEnrolled);

                    applicationFee = Integer.parseInt(ApplicationFeeField.getText());
                    output.writeInt(applicationFee);

                    applicationDeadline = ApplicationDeadlineField.getText();
                    output.writeUTF(applicationDeadline);

                    // clear the TextFields
                    UniversityNameField.setText("");
                    MinGPARequiredField.setText("");
                    OutOfStateTuitionField.setText("");
                    InStateTuitionField.setText("");
                    AcceptanceRateField.setText("");
                    GraduationRateField.setText("");
                    StudentsEnrolledField.setText("");
                    ApplicationFeeField.setText("");
                    ApplicationDeadlineField.setText("");

                }
            } catch (NumberFormatException nfe) {
                System.err.println(
                        "You must enter an integer phone number");
            } catch (IOException io) {
                System.err.println(
                        "Error during write to file\n"
                        + io.toString());
                System.exit(1);
            }
        }
    }

    public static void main(String args[]) {
        WriteUniversityInfo writeUniversityInfo = new WriteUniversityInfo();
    }
}
